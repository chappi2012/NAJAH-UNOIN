# 🏆 NAJAH Union — Team Platform

A **dark mode, colorful, fully functional** class team management platform.

## ✨ Features

- 🎨 **Dark Mode + Vibrant Colors** — Beautiful gradient UI
- 🏆 **Team Management** — Create up to 8 teams with custom colors
- 👥 **Member Leaderboard** — Track points and rankings
- ⚙️ **Admin Panel** — Full control over teams and members
- 📱 **Responsive Design** — Works on desktop and mobile
- ⚡ **No Backend Needed** — Runs entirely in the browser

## 🚀 Quick Start

1. Download `index.html`
2. Open in any web browser
3. Log in: `admin@example.com` / `admin123`
4. Go to **⚙️ Admin Panel** to customize teams!

## 📋 Login Credentials

**Admin Account:**
- Email: `admin@example.com`
- Password: `admin123`

Or create a new account by clicking **Sign Up**

## 🎯 How to Use

### Dashboard
- See all teams and their total points
- View member leaderboard

### Admin Panel
- **Team Settings:** Change number of teams, customize colors
- **Member Management:** Add members, assign to teams, set points

## 🌐 Deployment

### Deploy on Netlify (Free & Easy)

1. Push this repo to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Click "New site from Git" → Select your repo
4. Click "Deploy" — Done! 🎉

Your site will be live in seconds!

## 💡 Tips

- Teams are stored in browser memory (data resets on refresh)
- For permanent storage, upgrade to the Supabase backend version
- Change login credentials by editing the JavaScript code
- Customize colors by changing the CSS variables

## 📞 Next Steps

- Want permanent data storage? Use the **Supabase + Next.js** version
- Want to change the theme? Edit the CSS `:root` variables
- Want to add more features? Check the JavaScript code (well-commented)

---

**Built with ❤️ for NAJAH Class Union**
